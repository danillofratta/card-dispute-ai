from dispute_analyst.domain.entities.card import Card
from dispute_analyst.domain.entities.transaction import Transaction
from typing import Protocol


class CoreBanking(Protocol):
    """Core Banking system interface for interacting with banking operations."""

    async def get_transaction(self, transaction_id: str) -> Transaction | None: 
        """Retrieve a transaction by its ID, or return None if not found."""

    async def get_card(self, card_id: str) -> Card | None:  
        """Retrieve a card by its ID, or return None if not found."""